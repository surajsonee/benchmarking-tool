# Lambda - Java Maven Project
This is a Lambda project with Java Run time

## Requirements
	- maven
	- java
	- git
	- aws cli


# Build local
	- mvn clean package

# run local
	- java -jar target/emporiaenergy-client-1.0-SNAPSHOT.jar



